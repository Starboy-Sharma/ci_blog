<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function register()
	{
		$data['title'] = 'SignUp';

		$this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('zipcode', 'Zipcode', 'required');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|callback_check_username_exists');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[password]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/header');
			$this->load->view('users/register', $data);
			$this->load->view('templates/footer');
		} else {
			// Encrypt Password
			$enc_type = md5($this->input->post('password'));
			$this->user_model->register($enc_type);	

			// Set message
			$this->session->set_flashdata('user_registered', 'Registeration successful now you can login');

			redirect('posts');
		}
	}

	public function login()
	{
		$data['title'] = 'Log In';

		// Set rules for form-validation
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('templates/header');
			$this->load->view('users/login', $data);
			$this->load->view('templates/footer');
		} else {
			// Take username and password
			$username = $this->input->post('username');
			$password = md5($this->input->post('password'));

			// Login User
			$user_id = $this->user_model->login($username, $password);

			if ($user_id) {
			// Create Session
				$user_data = array(
					'user_id'   => $user_id,
					'username'  => $username,
					'logged_in' => true
				);

				$this->session->set_userdata($user_data);

			// Set flash Message
			$this->session->set_flashdata('user_loggedin', 'You are now Login');
			redirect('posts');

			} else {
				$this->session->set_flashdata('login_faliled', 'Incorrect Username and Password');
				redirect('users/login');
			}


		}
	}

	public function check_username_exists($username)
	{
		$this->form_validation->set_message('check_username_exists', 'Username is already taken. Please try with a different username');

		if ($this->user_model->check_username_exists($username)) {
			return true;
		} else {
			return false;
		}
	}

	public function check_email_exists()
	{
		$email =  $_POST['email'];

		if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			if($this->user_model->check_email_exists($email))
			{
				echo 'valid';
			} else { echo 'invalid';; }

		} else { return false; }
	}

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */