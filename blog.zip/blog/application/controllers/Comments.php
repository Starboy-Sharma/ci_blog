<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comments extends CI_Controller {

	public function create($post_id)
	{
			/* We need slug when we refresh our view then it need again to load post
			* and if you remeber we load a single post on the basis of slug
			* Note:- We take slug as a hidden input in our comment form
			*/
			$slug = $this->input->post('slug');
			$data['post'] = $this->post_model->get_posts($slug);
			$post_id = $data['post']['id'];
		
			$data['comments'] = $this->comment_model->get_comments($post_id);

			// Set Validation Rules
			$this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('message', 'Message', 'required');

			if ($this->form_validation->run() == FALSE) {
				$this->load->view('templates/header');
				$this->load->view('posts/view', $data);
				$this->load->view('templates/footer');
			} else {		
				$this->comment_model->create_comment($post_id);
				redirect('posts/'.$slug);
			}
	}

}

/* End of file Comments.php */
/* Location: ./application/controllers/Comments.php */