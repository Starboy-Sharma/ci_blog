<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Latest Posts';
		$data['posts'] = $this->post_model->get_posts();

		// Laod View

		$this->load->view('templates/header');
		$this->load->view('posts/index', $data);
		$this->load->view('templates/footer');
	}

	public function view($slug = NULL)
	{

		$data['post'] = $this->post_model->get_posts($slug);
		if (empty($data['post'])) {
			show_404();
		}

		$data['title']	 = "Vanshu";
		$post_id = $data['post']['id'];
		
		$data['comments'] = $this->comment_model->get_comments($post_id);

		// var_dump($data['title']); die();
		$this->load->view('templates/header');
		$this->load->view('posts/view', $data);
		$this->load->view('templates/footer');		
	}
	
	public function create()
	{
		$data['title'] = 'Create Posts';

		$data['categories'] = $this->post_model->get_categories();
		$data['errors'] = '';

		// Set Rules
		$this->form_validation->set_rules('title', 'Title', 'trim|required');
		$this->form_validation->set_rules('body', 'Body', 'required');
		$this->form_validation->set_rules('category', 'Category', 'required');

		if ($this->form_validation->run() === FALSE) {
			$this->load->view('templates/header');
			$this->load->view('posts/create', $data);
			$this->load->view('templates/footer');	
		} else {

			// Uplaod Image	
			$config['upload_path'] = './assets/posts';
			$config['encrypt_name'] = TRUE;
			$config['allowed_types'] = 'gif|jpg|jpeg|png';
			$config['max_size'] = '2048';
			

			$this->load->library('upload', $config);

			// Show Uplaods Errors
			if (!$this->upload->do_upload('userImage')) {
				$errors = array('errors' => $this->upload->display_errors());
				$data['title'] = 'Create Post';
				$data['errors'] = $errors;
				$this->load->view('templates/header');
				$this->load->view('posts/create', $data);
				$this->load->view('templates/footer');
				
			} 
			else 
			{
				// Uplaod Image		
				$data = array('upload_data' => $this->upload->data());
				// Grab the image name
				$post_image = $data['upload_data']['file_name'];
				// echo '<pre>'; print_r($data); die();
				
				// Set Flashmessage
				$this->session->set_flashdata('post_created', 'Your post has been created');

				$this->post_model->create_post($post_image);
				redirect('posts','refresh');
			}
		}

		
	}

	public function edit($slug)
	{
		$data['post'] = $this->post_model->get_posts($slug);
		if (empty($data['post'])) {
			show_404();
		}

		$data['title']	 = "Edit Post";
		$data['categories'] = $this->post_model->get_categories();
		// echo '<pre>'; print_r($data); die();
		$this->load->view('templates/header');
		$this->load->view('posts/edit', $data);
		$this->load->view('templates/footer');	
	}

	public function update()
	{
		$this->post_model->update_post();
		// Set flash message
		$this->session->set_flashdata('post_update', 'Post has been updated');

		redirect('posts','refresh');
	}

	public function delete($id)
	{
		$this->post_model->delete_post($id);
		// Set flash message
		$this->session->set_flashdata('post_delete', 'Your post has been deleted');
		redirect('posts','refresh');
	}

}

/* End of file Posts.php */
/* Location: ./application/controllers/Posts.php */