<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {

	public function index()
	{
		$data['title'] = "Categories";
		// Get Categoreis
		$data['categories'] = $this->category_model->get_categories();

		$this->load->view('templates/header');
		$this->load->view('categories/index', $data);
		$this->load->view('templates/footer');
	}

	public function create()
	{
		
		$data['title'] = 'Create Category';
		$this->form_validation->set_rules('name', 'Name', 'trim|required');

		if ($this->form_validation->run() == FALSE) {
			// Load Category insert view
			$this->load->view('templates/header');
			$this->load->view('categories/create', $data);
			$this->load->view('templates/footer');
		} else {
			
			$this->category_model->create_category();
			// Set flash message
			$this->session->set_flashdata('category_create', 'New Category has been added.');
			redirect('categories','refresh');
		}
	}

	public function posts($id)
	{
		// Here We Grab the name of Category
		$data['title'] = $this->category_model->get_category($id)->name;

		// Get Posts By Category id

		$data['posts'] = $this->post_model->get_post_by_category($id);

		// Load View Template
			$this->load->view('templates/header');
			$this->load->view('posts/index', $data);
			$this->load->view('templates/footer');
	}


}

/* End of file Categories.php */
/* Location: ./application/controllers/Categories.php */ 