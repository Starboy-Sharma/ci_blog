<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {

	public function index()
	{
				
	}

	public function view($page = 'home') 
	{
		// If page not exists

		if (!file_exists(APPPATH.'views/pages/'.$page.'.php')) {
			show_404();
		}

		$data['title'] = ucfirst($page);

		// Laod View

		$this->load->view('templates/header');
		$this->load->view('pages/'.$page, $data);
		$this->load->view('templates/footer');

	}

}

/* End of file Pages.php */
/* Location: ./application/controllers/Pages.php */