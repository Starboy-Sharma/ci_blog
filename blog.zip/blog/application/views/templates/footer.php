		</div>

		<!-- Jquery -->
		<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$('#email').on('blur', function(){
					var email = $('#email').val();

					// Let's do magic
					if($.trim(email).length > 0)
					{

					$.ajax({
						url: "<?php echo base_url(); ?>users/check_email_exists",
						type: "POST",
						dataType: "text",
						data: {email: email},
						success: function(data) {
							// console.log(data);
							
							if(!data) {
								$('#email-err').html('');
								$('#email-err').addClass("text-danger");
								$('#email-err').html('Invalid email id');
							}

							if (data == 'invalid') {
								$('#email-err').html('');
								$('#email-err').addClass("text-danger");
								$('#email-err').html('Email has been already in use.')
							}

							if (data == 'valid') {
								$("email-err").html('');
								$('#email-err').removeClass("text-danger");
								$('#email-err').addClass("text-success");
								$('#email-err').html("Valid email id.");
							}
						}
					});

					} 

				});
			});
		</script>

		<!-- CKEDITOR -->
		<script src="https://cdn.ckeditor.com/4.10.0/standard/ckeditor.js"></script>
		<script type="text/javascript">
			CKEDITOR.replace( 'editor1' );
		</script>
	</body>
</html>