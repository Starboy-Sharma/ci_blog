<?php echo validation_errors();
  if(!empty($errors)) {  foreach ($errors as $error) : ?>
    <span class="text-danger">  <?php echo '<br>'.$error; ?> </span>
  <?php endforeach; } ?>

<form action="create" enctype="multipart/form-data" method="post">
  <fieldset>
    <legend> <?php echo $title; ?> </legend>
    
    <div class="form-group">
      <label for=""> Title </label>
      <input type="text" class="form-control" id="exampleInputEmail1" name="title" placeholder="Add Title">
     
    </div>
    
    <div class="form-group">
      <label >Body</label>
      <textarea class="form-control" name="body" id="editor1" rows="3"></textarea>
    </div>
 
    <div class="form-group">
      <select name="category" class="form-control"> 
        <option></option>
        <?php  foreach ($categories as $category) { ?>
            <option value="<?php echo $category['id'] ?>"> <?php echo $category['name']; ?> </option>
        <?php } ?>
       </select>
    </div>

    <div class="form-froup">
      <label> Upload Image </label>
      <input type="file" name="userImage" size="20" class="form-control">
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
  <br>
</form>