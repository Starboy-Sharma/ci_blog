<section class="blogs">
	<div class="row">
		<div class="col-md-12">
				
			<h3> <?php echo $post['title']; ?>  </h3>

			<img src="<?php echo site_url().'assets/posts/'. $post['image']; ?>" class="img-responsive" style="width: 700px; height: auto;" >
			<p style="padding: 0em 1em; margin-top: 10px; font-size: 16px;"> 
				<?php echo $post['body']; ?>
			</p>
			<span> <img src="https://png.icons8.com/ios/50/009688/ingredients.png" class="img-responsive" > <?php  echo $post['created_at']; ?> </span>
			
			<br><br>
			<a class="btn btn-primary" href="edit/<?php echo $post['slug']; ?>" style="display: inline-block; float: left; margin-right: 7px;"> Edit </a>
			<?php  echo form_open('/posts/delete/'.$post['id']); ?>
				<input type="submit" value="Delete" class="btn btn-danger">
			</form>


			<br>

			<strong> Share Post: </strong>
			<ul class="social-icons text-center">
			<li><img src="https://png.icons8.com/color/50/009688/facebook.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/instagram-new.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/google-logo.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/pinterest.png" class="img-responsive"></li>
		</ul>
		</div>
	</div>
</section>

<hr>

<h3> Recent Comments </h3>

<?php if($comments) : ?>
	<?php foreach ($comments as $comment) : ?>
		<div class="well">
			<h5> <?php echo $comment['body']; ?> [ by <strong> <?php echo $comment['name']; ?> </strong> ] 
			</h5>
			<em> Email: <?php echo $comment['email']; ?> </em>
		</div>
	<?php endforeach; ?>
<?php else :  ?>
	<p> No Comments here... </p>
<?php endif; ?>	
<!-- Comments -->
<hr>

<!-- Comment Form -->

<div class="row">
	<div class="col">
	<h3>Add Comment</h3>
	<?php echo validation_errors(); ?>
	<?php echo form_open('comments/create/'.$post['id']); ?>
<div class="form-group">
	<label>Name</label>
	<input type="text" name="name" class="form-control">
</div>

<div class="form-group">
	<label>Email</label>
	<input type="text" name="email" class="form-control">
</div>

<div class="form-group">
	<label>Body</label>
	<textarea name="message" class="form-control"></textarea>
</div>
<input type="hidden" name="slug" value="<?php echo $post['slug'] ?>">
<button class="btn btn-primary" type="submit">Submit</button>
</form>
</div>
</div>

<br><br>