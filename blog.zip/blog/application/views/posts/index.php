<h2> <?= $title; ?> </h2>

<section class="blogs">
<div class="row">
	<div class="col-md-8">
		
		<?php
		// Fetch Posts From Database

		foreach ($posts as $post) { ?>
		<div class="row">	
			<h3> <?php echo $post['title']; ?>  </h3> 
			
			<div class="image">
				<img src="<?php echo site_url().'assets/posts/'.$post['image']; ?>" class="img-responsive">
			</div>

			<div class="content">
			<p> <?php echo word_limiter($post['body'], 65); ?> </p>
			<span> <img src="https://png.icons8.com/ios/50/009688/ingredients.png" class="img-responsive"> <?php  echo $post['created_at']; ?> Category: <strong> <?php echo $post['name']; ?> </strong> </span>

			<p> <a href="<?php echo site_url('/posts/'.$post['slug']) ?>" style="text-decoration: none;" class="btn btn-danger"> Read More </a> </p>
			</div>

		</div>
		<?php } ?>

		<h3> chili garlic instant pot noodles </h3>
		<img src="https://images.pexels.com/photos/8758/food-dinner-lemon-rice.jpg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" class="img-responsive">
		<p>
			Are noodles the best or are noodles the best? </p>

<p>They are the actual best. You can build almost any type of meal around almost any type of noodles. God bless them, every one.
</p>
<p>
Today I’m going to introduce you to an idea that is a Zero Thinking Required Dinner Situation. Spoiler: it includes noodles.
</p>
<p>
Meet: Chili garlic brown rice noodles in the Instant Pot (affiliate link). They are sticky, with an umami flavor and a little sweetness. They are gorgeous, because we get fancy with our toppings. They are laced with a little chili garlic and speckled with red peppers and scallions and peanuts and saucy bites of chicken for those who want it and tofu/other for those who don’t.
</p>
<p>Yeah. Those are the ones.
		</p>
	</div>
	
	<div class="col-md-4">
		<h3 class="text-center"> About Me </h3>
		<img src="https://images.pexels.com/photos/132694/pexels-photo-132694.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" class="img-responsive" style="border-radius: 50%; width: 350px; height: 300px;">

		<ul class="social-icons">
			<li><img src="https://png.icons8.com/color/50/009688/facebook.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/instagram-new.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/google-logo.png" class="img-responsive"></li>
			<li><img src="https://png.icons8.com/color/50/009688/pinterest.png" class="img-responsive"></li>
		</ul>

		<h3> Recent Posts </h3>
		<div class="posts"> Loading.... </div>

	</div>
	
</div>	
</section>