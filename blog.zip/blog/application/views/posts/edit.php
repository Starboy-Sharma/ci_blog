<?php 

  echo validation_errors();

?>

<?php echo form_open_multipart('posts/update'); ?>
  <fieldset>
    <legend> <?php echo $title; ?> </legend>
    
    <div class="form-group">
      <label for=""> Title </label>
      <input type="text" class="form-control" value="<?php echo $post['title']; ?>" id="exampleInputEmail1" name="title" placeholder="Add Title">
     
    </div>
    
    <div class="form-group">
      <label >Body</label>
      <textarea class="form-control" name="body" id="editor1" rows="3"> <?php echo $post['body']; ?> </textarea>
    </div>
    <div class="form-group">
      <select name="category" class="form-control"> 
        
        <?php  foreach ($categories as $category) { ?>
            <option value="<?php echo $category['id'] ?>"> <?php echo $category['name']; ?> </option>
        <?php } ?>
       </select>
    </div>
    <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>