<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function register($enc_type)
	{
		$data = array(
			"name" 			=>  $this->input->post('name'), 
			"zipcode" 		=>  $this->input->post('zipcode'), 
			"email" 		=>  $this->input->post('email'), 
			"password" 		=>  $enc_type,
			"username"  	=>  $this->input->post('username') 
		);

		return $this->db->insert('users', $data);

	}

	public function check_username_exists($username) {

		$query = $this->db->get_where('users', array("username"	 => $username ));

		if (empty($query->row_array())) {
			return true;
		} else { return false; }
	}

	public function check_email_exists($email) {

		$query = $this->db->get_where('users', array("email" => $email ));

		if (empty($query->row_array())) {
			return true;
		} else { return false; }
	}

	public function login($u, $p)
	{		
		$this->db->where('username', $u);
		$this->db->where('password', $p);

		$result = $this->db->get('users');

		if ($result->num_rows() == 1) {
			return $result->row(0)->id;
		} else {
			return false;
		}
	}



}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */